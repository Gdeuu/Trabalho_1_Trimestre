document.addEventListener("DOMContentLoaded", function() {
    const banners = document.querySelectorAll("img[id^='banner_']");
    
    banners.forEach(banner => {
        banner.addEventListener("click", function() {
            const contentId = this.id + "_content";
            const contentElement = document.getElementById(contentId);
            
            // Fecha todos os outros conteúdos
            document.querySelectorAll("[id$='_content']").forEach(content => {
                if (content.id !== contentId) {
                    content.style.display = "none";
                }
            });
            
            // Alterna o conteúdo clicado
            if (contentElement.style.display === "block") {
                contentElement.style.display = "none";
            } else {
                contentElement.style.display = "block";
            }
        });
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const mainButton = document.getElementById("accessibility-main-button");
    const optionsDiv = document.getElementById("accessibility-options");
    const increaseFontButton = document.getElementById("increase-font-button");
    const decreaseFontButton = document.getElementById("decrease-font-button");
    const toggleThemeButton = document.getElementById("toggle-theme-button");
    let fontSize = 200;

    mainButton.addEventListener("click", function () {
        optionsDiv.style.display = optionsDiv.style.display === "block" ? "none" : "block";
    });

    increaseFontButton.addEventListener("click", function () {
        fontSize += 10;
        adjustTextSize(fontSize);
    });

    decreaseFontButton.addEventListener("click", function () {
        fontSize = Math.max(50, fontSize - 10); // Evita reduzir demais
        adjustTextSize(fontSize);
    });

    toggleThemeButton.addEventListener("click", function () {
        document.body.classList.toggle("light-theme");
    });

    
    function adjustTextSize(size) {
        document.querySelectorAll("h1, h2, h3, h4, h5, h6, p").forEach(function (el) {
            if (!el.classList.contains("immutable")) {  // Ignora elementos com a classe 'immutable'
                el.style.fontSize = `${size}%`;
            }
        });
    }
})
